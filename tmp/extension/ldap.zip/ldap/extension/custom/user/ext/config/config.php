<?php
// LDAP login requires the original password
$config->notMd5Pwd = true;
