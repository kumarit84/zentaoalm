<?php
$config->ldap = new stdclass();
$config->ldap->turnon = 0;
$config->ldap->version = 3;